# Vantegris email signature — template "A1 · Soft Lime"

The design is a 600 px card: the top part has the photo, name, contacts, a "Schedule a meeting" button and social icons, and the bottom part is a stats band. `build.py` renders the card for each person, cuts it into image slices, and writes a Gmail-ready HTML table. In that table, the phone, email, Telegram, button, socials and logo are all clickable. Gmail removes gradients and web fonts from signatures, so the design is sent as images. The disclaimer stays live text.

```
vantegris/
├── config.json            company-wide: links, stats, ticker, disclaimer
├── people/
│   ├── people.json        one entry per person
│   └── photos/            source photos
├── template/
│   ├── signature.html     the design (edit this to change the look for everyone)
│   ├── fonts/  assets/    Montserrat, JetBrains Mono, Archivo, Vantegris logo
├── build.py
└── output/<slug>/
    ├── signature.html     ← paste this into Gmail
    ├── signature.png      full preview (2x)
    ├── photo.jpg          cropped photo
    └── s/01.png …         slices referenced by signature.html
```

## Add a person

1. Put the photo in `people/photos/` (JPG or PNG, ideally 800 px or larger).
2. Add an entry to `people/people.json`:

```json
{
  "slug": "firstname-lastname",
  "name": "Lastname Firstname",
  "title": "Associate, Vantegris",
  "phone": "+372 0000 0000",
  "email": "f.lastname@vantegris.com",
  "telegram": "@handle",
  "photo": "photos/firstname-lastname.jpg",
  "photo_crop": [left, top, size]
}
```

The optional fields work like this:

- **`photo_crop`**: a square in source-photo pixels. If you leave it out, the script takes a square from the top centre of the photo.
- **`telegram_link`**: overrides the default `https://t.me/<handle>`.
- **Per-person links**: `meeting_url`, `linkedin_url` and the other link fields from `config.json` can be set on a person to replace the company-wide value for them.

## Build

```bash
pip install playwright pillow && playwright install chromium   # once
python3 build.py                      # everyone
python3 build.py firstname-lastname   # one person
```

The script prints the size of the HTML. Gmail's limit is 10,000 characters, and the current design comes to about 8,500.

## Install in Gmail

1. Commit and push `output/` to `main`. The images load from `raw.githubusercontent.com`, so they must be on GitHub first.
2. Open `https://raw.githack.com/akopivska-code/email-signature/main/vantegris/output/<slug>/signature.html`. Alternatively, download the file and open it in Chrome.
3. Select everything with Cmd+A, copy it with Cmd+C, then go to Gmail → Settings → Signature, paste it with Cmd+V, and save.

## Before going live

Replace the `TODO` links in `config.json`: the meeting link, LinkedIn and the Telegram channel.
