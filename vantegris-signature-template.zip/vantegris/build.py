#!/usr/bin/env python3
"""
Build Vantegris email signatures from template/signature.html.

For every person in people/people.json it:
  1. crops the photo to a square (people/photos -> output/<slug>/photo.jpg)
  2. fills the template and renders it at 2x with Playwright
  3. saves the full image (output/<slug>/signature.png)
  4. slices it so every data-link element becomes a clickable image
  5. writes the Gmail-ready table (output/<slug>/signature.html) whose
     images point at raw_base_url — push the output folder to GitHub first.

Usage:
  python3 build.py                 # all people
  python3 build.py iryna-hrabovetska   # one person
Requires: pip install playwright pillow  &&  playwright install chromium
"""
import html, json, re, shutil, sys
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
TEMPLATE = ROOT / "template" / "signature.html"
OUT = ROOT / "output"
SCALE = 2          # retina-sharp slices, displayed at 1x
GMAIL_LIMIT = 10000


def esc(s):
    return html.escape(str(s), quote=True)


def prep_photo(person, dest):
    src = Image.open(ROOT / "people" / person["photo"]).convert("RGB")
    crop = person.get("photo_crop")          # [left, top, size] in source pixels
    if crop:
        l, t, s = crop
    else:                                    # default: square from the top-centre (keeps the face)
        s = min(src.size)
        l, t = (src.width - s) // 2, 0
    src.crop((l, t, l + s, t + s)).resize((420, 420), Image.LANCZOS).save(dest, quality=92)


def fill(cfg, p, photo_name):
    tg = p.get("telegram", "")
    tokens = {
        "name": esc(p["name"]),
        "title": esc(p.get("title", "")),
        "phone": esc(p.get("phone", "")),
        "phone_link": "tel:" + re.sub(r"[^\d+]", "", p.get("phone", "")),
        "email": esc(p.get("email", "")),
        "telegram": esc(tg),
        "telegram_link": p.get("telegram_link") or ("https://t.me/" + tg.lstrip("@")),
        "photo": photo_name,
        "stats_html": "".join(
            f'<div class="stat"><div class="num">{n}<span>+</span></div><div class="cap">{c}</div></div>'
            for n, c in cfg["stats"]),
        "ticker_html": ' <span class="dot"></span> '.join(esc(t).upper() for t in cfg["ticker"]),
    }
    for k in ("site_url", "site_label", "meeting_url", "linkedin_url",
              "telegram_channel_url", "tagline"):
        tokens[k] = esc(p.get(k) or cfg[k])
    page = TEMPLATE.read_text(encoding="utf-8")
    for k, v in tokens.items():
        page = page.replace("{{" + k + "}}", v)
    left = re.findall(r"\{\{\w+\}\}", page)
    if left:
        raise SystemExit(f"Unfilled tokens: {left}")
    return page


def plan_rows(W, H, links):
    """Cut the card into horizontal bands; inside a band, each link fully covering it is a cell."""
    ys = sorted({0, H, *[l["y0"] for l in links], *[l["y1"] for l in links]})
    bands = []
    for y0, y1 in zip(ys, ys[1:]):
        inside = sorted([l for l in links if l["y0"] <= y0 and l["y1"] >= y1], key=lambda l: l["x0"])
        cells, x = [], 0
        for l in inside:
            if l["x0"] > x:
                cells.append((x, l["x0"], None, ""))
            cells.append((l["x0"], l["x1"], l["href"], l["alt"]))
            x = l["x1"]
        if x < W:
            cells.append((x, W, None, ""))
        sig = [(a, b, h) for a, b, h, _ in cells]
        if bands and bands[-1]["sig"] == sig:        # same structure -> merge vertically
            bands[-1]["y1"] = y1
        else:
            bands.append({"y0": y0, "y1": y1, "sig": sig, "cells": cells})
    return bands


def build(person, cfg, pw):
    slug = person["slug"]
    out = OUT / slug
    if out.exists():
        shutil.rmtree(out)
    (out / "s").mkdir(parents=True)

    work = ROOT / "template" / f"_render_{slug}.html"
    photo_tmp = ROOT / "template" / f"_photo_{slug}.jpg"
    prep_photo(person, photo_tmp)
    work.write_text(fill(cfg, person, photo_tmp.name), encoding="utf-8")

    try:
        browser = pw.chromium.launch()
        page = browser.new_page(viewport={"width": 600, "height": 900}, device_scale_factor=SCALE)
        page.goto(work.as_uri())
        page.evaluate("document.fonts.ready")
        page.wait_for_timeout(200)
        card = page.locator("#card")
        card.screenshot(path=str(out / "signature.png"))
        box = card.bounding_box()
        links = page.evaluate("""(o) => [...document.querySelectorAll('[data-link]')].map(e => {
            const r = e.getBoundingClientRect();
            return {x0: Math.round(r.left - o.x), y0: Math.round(r.top - o.y),
                    x1: Math.round(r.right - o.x), y1: Math.round(r.bottom - o.y),
                    href: e.dataset.link, alt: e.dataset.alt || e.alt || ''};
        })""", box)
        browser.close()
    finally:
        work.unlink(missing_ok=True)

    shutil.copy(photo_tmp, out / "photo.jpg")
    photo_tmp.unlink(missing_ok=True)

    full = Image.open(out / "signature.png").convert("RGB")
    W, H = round(full.width / SCALE), round(full.height / SCALE)
    base = f'{cfg["raw_base_url"].rstrip("/")}/{slug}/s'

    rows, n = [], 0
    for band in plan_rows(W, H, links):
        y0, y1 = band["y0"], band["y1"]
        tds = []
        for x0, x1, href, alt in band["cells"]:
            n += 1
            name = f"{n:02d}.png"
            full.crop((x0 * SCALE, y0 * SCALE, x1 * SCALE, y1 * SCALE)).save(out / "s" / name, optimize=True)
            img = (f'<img src="{base}/{name}" width="{x1-x0}" height="{y1-y0}" alt="{esc(alt)}" '
                   f'style="display:block;border:0">')
            if href:
                img = f'<a href="{esc(href)}">{img}</a>'
            tds.append(f'<td style="padding:0;line-height:0;font-size:0">{img}</td>')
        rows.append('<tr><td style="padding:0"><table cellpadding="0" cellspacing="0" border="0" '
                    'style="border-collapse:collapse"><tr>' + "".join(tds) + '</tr></table></td></tr>')

    d = cfg["disclaimer"]
    disc = "<br>".join(esc(x) for x in (d if isinstance(d, list) else [d]))
    disclaimer = (f'<tr><td style="padding:12px 2px 0;font-family:Arial,sans-serif;font-size:9.5px;'
                  f'line-height:1.4;color:#707784">{disc}</td></tr>')
    table = ('<table cellpadding="0" cellspacing="0" border="0" width="600" '
             'style="border-collapse:collapse;width:600px">' + "".join(rows) + disclaimer + '</table>')
    (out / "signature.html").write_text(table + "\n", encoding="utf-8")

    # tight preview of the final email signature (no empty space around it)
    local = table.replace(base, (out / "s").as_uri())
    tmp = out / "_preview.html"
    tmp.write_text('<html><body style="margin:0;background:#fff">' + local + '</body></html>', encoding="utf-8")
    browser = pw.chromium.launch()
    pg = browser.new_page(viewport={"width": 600, "height": 900}, device_scale_factor=SCALE)
    pg.goto(tmp.as_uri())
    pg.wait_for_timeout(200)
    pg.locator("table").first.screenshot(path=str(out / "preview.png"))
    browser.close()
    tmp.unlink()
    print(f"✓ {slug}: {n} slices, {len(table)} chars (Gmail limit {GMAIL_LIMIT})"
          + ("  ⚠ OVER LIMIT" if len(table) > GMAIL_LIMIT else ""))


def main():
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    people = json.loads((ROOT / "people" / "people.json").read_text(encoding="utf-8"))
    only = set(sys.argv[1:])
    todo = [p for p in people if not only or p["slug"] in only]
    if not todo:
        raise SystemExit("No matching people.")
    if any("TODO" in str(cfg[k]) for k in cfg if k.endswith("_url")):
        print("⚠ config.json still has TODO links (meeting / socials).")
    with sync_playwright() as pw:
        for p in todo:
            build(p, cfg, pw)


if __name__ == "__main__":
    main()
